﻿using BigJacob.MVVM;
using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.ViewModel
{
    public class MainViewModel : BaseViewModel
    {
        #region Properties

        #endregion

        #region Commands

        #endregion

        #region Methods

        #endregion
    }
}